public class Action {

    private Direction movingDirection;
    private Tile movingTile;

    public Action(Direction movingDirection, Tile movingTile) {
        this.movingDirection = movingDirection;
        this.movingTile = movingTile;
    }

    public Direction getMovingDirection() {
        return movingDirection;
    }

    public void setMovingDirection(Direction movingDirection) { // צריך לבדוק שהשינוי תקין לפני שמבצעים
        this.movingDirection = movingDirection;
    }

    public Tile getMovingTile() {
        return movingTile;
    }

    public void setMovingTile(Tile movingTile) { // צריך לבדוק שהשינוי תקין לפני שמבצעים
        this.movingTile = movingTile;
    }

    @Override
    public String toString(){
        String directionString = " nowhere";
        switch (movingDirection){
            case UP:
                directionString = " up";
                break;
            case DOWN:
                directionString = " down";
                break;
            case RIGHT:
                directionString = " right";
                break;

            case LEFT:
                directionString = " left";
                break;
        }
        return "Move" + movingTile + directionString;
    }
}