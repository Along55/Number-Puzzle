public class State {

    private Board board;

    public State(Board input) {
        this.board = input;
    }

    public boolean isGoal (){
        Board targetBoard = new Board(Board.getNumOfRows(board.toString()), Board.getNumOfColumns(board.toString()));
        return board.equals(targetBoard);
    }

    public Action[] Actions(){
    int[] zeroIndex;
    zeroIndex = this.board.findZero();
    Action[] allActions = new Action[4];
    int counter = 0;
    if (this.board.getTiles()[zeroIndex[0]-1][zeroIndex[1]] == null)
        counter++;
    else
        allActions[0] = new Action(Direction.UP,board.getTiles()[zeroIndex[0]-1][zeroIndex[1]]);
    if (this.board.getTiles()[zeroIndex[0]+1][zeroIndex[1]] == null)
        counter++;
    else
        allActions[1] = new Action(Direction.DOWN,board.getTiles()[zeroIndex[0]+1][zeroIndex[1]]);
    if (this.board.getTiles()[zeroIndex[0]][zeroIndex[1]-1] == null)
        counter++;
    else
        allActions[2] = new Action(Direction.RIGHT,board.getTiles()[zeroIndex[0]][zeroIndex[1]-1]);
    if (this.board.getTiles()[zeroIndex[0]][zeroIndex[1]+1] == null)
        counter++;
    else
        allActions[3] = new Action(Direction.LEFT,board.getTiles()[zeroIndex[0]][zeroIndex[1]+1]);
    Action[] actions = new Action[4-counter];
    int j =0;
    for(int i=0; i < allActions.length; i++){
        if(allActions[i] != null) {
            actions[j] = allActions[i];
            j++;
        }
        }
    return actions;
    }

    public State result (Action action){
        int[] zeroIndex;
        zeroIndex = this.board.findZero();
        Board copyBoard = new Board(this.board.toString());
        if (action.getMovingDirection().equals(Direction.UP)){
            copyBoard.getTiles()[zeroIndex[0]][zeroIndex[1]].setValue(action.getMovingTile().getValue());
            copyBoard.getTiles()[zeroIndex[0]-1][zeroIndex[1]].setValue(0);
        }
        if (action.getMovingDirection().equals(Direction.DOWN)){
            copyBoard.getTiles()[zeroIndex[0]][zeroIndex[1]].setValue(action.getMovingTile().getValue());
            copyBoard.getTiles()[zeroIndex[0]+1][zeroIndex[1]].setValue(0);
        }
        if (action.getMovingDirection().equals(Direction.RIGHT)){
            copyBoard.getTiles()[zeroIndex[0]][zeroIndex[1]].setValue(action.getMovingTile().getValue());
            copyBoard.getTiles()[zeroIndex[0]][zeroIndex[1]-1].setValue(0);
        }
        if (action.getMovingDirection().equals(Direction.LEFT)){
            copyBoard.getTiles()[zeroIndex[0]][zeroIndex[1]].setValue(action.getMovingTile().getValue());
            copyBoard.getTiles()[zeroIndex[0]+1][zeroIndex[1]+1].setValue(0);
        }
        State result = new State(copyBoard);
        return result;
    }

    public static void main (String[] args){
        State myState = new State(new Board("1 2|3 0"));
        System.out.println(myState.isGoal());
    }

    @Override
    public boolean equals(Object other) {
        if (!(other instanceof State)) {
            return false;
        }
        State state = (State) other;
        return board.equals(state.board);
    }

    @Override
    public int hashCode() {
        return board.hashCode();
    }
}
