import java.util.Arrays;

import static java.util.Arrays.deepToString;

public class Board {

    private Tile[][] tiles;

    public Board(int numOfRows , int numOfColumn){
        tiles = new Tile[numOfRows][numOfColumn];
        int counter = 1;
        for (int i=0 ; i<tiles.length ; i++){
            for (int j=0 ; j<tiles[i].length ; j++){
                if (i >= tiles.length-1 && j >= (tiles[i].length-1))
                    tiles[i][j] = new Tile(0);
                else {
                    tiles[i][j] = new Tile(counter);
                    counter++;
                }
            }
        }
    }
    public Board(String board) {
        int row=0 , column=0 , num=0;
        this.tiles = new Tile[getNumOfRows(board)][getNumOfColumns(board)]; //Initialize board size
        for (int i=0 ; i<board.length() ; i++){
            if (board.charAt(i) == '|') {
                tiles[row][column] = new Tile(num);
                num=0;
                row++;
                column=0;
            }
            else if (board.charAt(i) == ' ') {
                tiles[row][column] = new Tile(num);
                num=0;
                column++;
            }
            else {
                num = num * 10 + (int)board.charAt(i)-48; //-48 because ascii code
                if (i+1>=board.length())
                    tiles[row][column] = new Tile(num);
            }
        }
    }

    public Board() {
        this("0");
    }

    public static int getNumOfRows (String board){
        int counter=1;
        for (int i=0 ; i<board.length() ; i++) {
            if (board.charAt(i) == '|') {
                counter++;
            }
        }
        return counter;
    }

    public static int getNumOfColumns (String board){
        int counter=1;
        boolean flag=true;
        for (int i=0 ; flag ; i++) {
            if (board.charAt(i) == '|' || i+1>=board.length()) {
                flag=false;
            }
            if (board.charAt(i) == ' '){
                counter++;
            }
        }
        return counter;
    }

    public int[] findZero (){
        int[] index = new int[2];
        for (int i = 0; i < this.tiles.length; i++)
            for (int j = 0; j < this.tiles[i].length; j++){
                if(this.tiles[i][j].getValue() == 0) {
                    index[0] = i;
                    index[1] = j;
                }
                return index;
            }
        return null; // shouldn't happen as long as the input is ok
    }


    public static void main (String[] args){
        Board myBoard = new Board(2,5);
        System.out.println(myBoard);
    }


    public Tile[][] getTiles() {
        return tiles;
    }

    public void setTiles(Tile[][] tiles) {
        this.tiles = tiles;
    }

    @Override
    public String toString(){
        String out="";
        for (int i=0 ; i < tiles.length; i++){
            for (int j=0 ; j < tiles[i].length; j++) {
                if (j + 1 < tiles[i].length)
                    out = out + tiles[i][j].getValue() + " ";
                else
                    out = out + tiles[i][j].getValue();
            }
            if (i + 1 < tiles.length)
                out = out + "|";
        }
        return out;
    }

    @Override
    public boolean equals(Object other) {
        if (!(other instanceof Board)) {
            return false;
        }
        Board board = (Board) other;
        return Arrays.deepEquals(tiles, board.tiles);
    }

    @Override
    public int hashCode() {
        return Arrays.deepHashCode(tiles);
    }
}
